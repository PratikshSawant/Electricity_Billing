/**
 * 
 */
/**
 * @author Lenovo
 *
 */
package com.ElectricityBillingSystem.entity;